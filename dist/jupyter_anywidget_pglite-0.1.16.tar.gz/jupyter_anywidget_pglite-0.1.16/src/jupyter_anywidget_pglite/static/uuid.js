function r(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(n){let x=Math.random()*16|0;return(n==="x"?x:x&3|8).toString(16)})}export{r as generateUUID};
